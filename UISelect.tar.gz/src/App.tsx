import _ from "lodash";
import UISelectController from "./components/UISelect/UISelectController";
// const testIndex = 28;
// console.log(data[testIndex].data.label);
// console.log(data[testIndex].child);
// console.log(data[testIndex].child.length);

// _.forEach(data[testIndex].child, (item) => {
//   console.log(item);
//   console.log(data[item].data.label);
// });

function App() {
  return <UISelectController />;
}
export default App;
