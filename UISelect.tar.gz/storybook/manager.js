import { addons } from '@storybook/addons';
import magezon from './magezon';

// https://storybook.js.org/docs/react/configure/features-and-behavior
addons.setConfig({
	theme: magezon
});
