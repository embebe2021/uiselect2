export const CATEGORY = {
  COMPONENTS: "UISelect",
  SINGLE: "UISelect Dropdown Menu type single line options",
  TREE: "UISelect Dropdown Menu type tree options",
  GROUP: "UISelect Dropdown Menu type group options",
  SEARCH: "UISelect Search online, offline",
};
